# Learn Enough HTML

This is the reference implementation for the sample website developed in <a href="https://www.learnenough.com/html"><em>Learn Enough HTML to Be Dangerous</em></a> by Michael Hartl and Lee Donahoe.

To report any errors or discrepancies with the text, please email michael@learnenough.com.